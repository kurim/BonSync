// modules-src/penny/index.ts
import { randomUUID } from "node:crypto";

// modules-src/_shared/posParser.ts
function parseAmountToCents(raw) {
  const normalized = raw.replace(/\./g, "").replace(",", ".");
  return Math.round(parseFloat(normalized) * 100);
}
var INVISIBLE_CODEPOINTS = [
  173,
  // SOFT HYPHEN
  ...range(8203, 8207),
  // ZERO WIDTH SPACE/JOINER/NON-JOINER, LTR/RTL MARK
  ...range(8234, 8238),
  // Bidi-Einbettung (LRE/RLE/PDF/LRO/RLO)
  8288,
  // WORD JOINER
  ...range(8294, 8297),
  // Bidi-Isolate (LRI/RLI/FSI/PDI)
  ...range(65024, 65039),
  // VARIATION SELECTOR-1..16
  65279
  // ZERO WIDTH NO-BREAK SPACE / BOM
];
function range(from, to) {
  const out = [];
  for (let i = from; i <= to; i++) out.push(i);
  return out;
}
var INVISIBLE_CHARS = new RegExp(`[${INVISIBLE_CODEPOINTS.map((c) => `\\u${c.toString(16).padStart(4, "0")}`).join("")}]`, "g");
function normalizeLine(rawLine) {
  return rawLine.replace(INVISIBLE_CHARS, " ").replace(/€\s?/g, "").replace(/\s+/g, " ").trim();
}
var PRICE = String.raw`-?\d{1,3}(?:\.\d{3})*,\d{2}`;
var ARTICLE_LINE = new RegExp(`^(.+?)\\s+(${PRICE})\\s*(\\*)?\\s*([A-Z])\\s*(\\*)?$`);
var QTY_ONLY_LINE = new RegExp(`^(\\d+)\\s*Stk\\s*x\\s*(${PRICE})\\s*$`, "i");
var QTY_PREFIX = new RegExp(`^(\\d+)\\s*Stk\\s*x\\s*(${PRICE})$`, "i");
var QTY_PREFIX_LINE = new RegExp(`^(\\d+)X\\s+(.+?)\\s+(${PRICE})\\s+(${PRICE})\\s*(\\*)?\\s*([A-Z])\\s*(\\*)?$`, "i");
function parseReceiptItems(lines) {
  const items = [];
  for (const rawLine of lines) {
    const line = normalizeLine(rawLine);
    if (!line) continue;
    if (/^SUMME\b/i.test(line) || /^Geg\.\s/i.test(line) || /^UID\s*Nr\.?:/i.test(line) || /^Markt:/i.test(line) || /EUR\s*gespart$/i.test(line) || /Treuepunkt/i.test(line) || /^\d{2}\.\d{2}\.\d{4}\s+\d{2}:\d{2}\s+Bon-Nr\.?:/i.test(line) || /^[A-Z]=\s*\d/.test(line)) {
      continue;
    }
    const qtyPrefixLineMatch = line.match(QTY_PREFIX_LINE);
    if (qtyPrefixLineMatch) {
      items.push({
        name: qtyPrefixLineMatch[2].trim(),
        priceCents: parseAmountToCents(qtyPrefixLineMatch[4]),
        quantity: parseInt(qtyPrefixLineMatch[1], 10),
        unitPriceCents: parseAmountToCents(qtyPrefixLineMatch[3]),
        taxCode: qtyPrefixLineMatch[6],
        discountExcluded: Boolean(qtyPrefixLineMatch[5] || qtyPrefixLineMatch[7])
      });
      continue;
    }
    const articleMatch = line.match(ARTICLE_LINE);
    if (articleMatch) {
      const namePart = articleMatch[1].trim();
      const totalPriceCents = parseAmountToCents(articleMatch[2]);
      const taxCode = articleMatch[4];
      const discountExcluded = Boolean(articleMatch[3] || articleMatch[5]);
      const qtyPrefixMatch = namePart.match(QTY_PREFIX);
      const pending = items[items.length - 1];
      if (qtyPrefixMatch && pending && pending.priceCents === 0 && pending.quantity === void 0) {
        pending.quantity = parseInt(qtyPrefixMatch[1], 10);
        pending.unitPriceCents = parseAmountToCents(qtyPrefixMatch[2]);
        pending.priceCents = totalPriceCents;
        pending.taxCode = taxCode;
        pending.discountExcluded = discountExcluded;
      } else {
        items.push({ name: namePart, priceCents: totalPriceCents, taxCode, discountExcluded });
      }
      continue;
    }
    const qtyOnlyMatch = line.match(QTY_ONLY_LINE);
    if (qtyOnlyMatch) {
      const prev = items[items.length - 1];
      if (prev && prev.priceCents !== 0 && prev.quantity === void 0) {
        prev.quantity = parseInt(qtyOnlyMatch[1], 10);
        prev.unitPriceCents = parseAmountToCents(qtyOnlyMatch[2]);
      }
      continue;
    }
    if (line.length > 1) {
      items.push({ name: line, priceCents: 0 });
    }
  }
  return items.filter((i) => i.priceCents !== 0 || i.quantity !== void 0);
}
var MARKET_LINE = /^Markt:(\S+)/i;
function parseMarketNumber(lines) {
  for (const rawLine of lines) {
    const line = rawLine.replace(/\s+/g, " ").trim();
    const match = line.match(MARKET_LINE);
    if (match) return match[1];
  }
  return null;
}
var TOTAL_SAVINGS_LINE = new RegExp(`(${PRICE})\\s*(?:EUR)?\\s*gespart`, "i");
var COUPON_LINE = new RegExp(`^(\\d{6,})\\s+(.+?)\\s+(${PRICE})$`);
function parseSavings(lines) {
  let totalSavingsCents = null;
  const coupons = [];
  let inCouponSection = false;
  for (const rawLine of lines) {
    const line = normalizeLine(rawLine);
    if (!line) continue;
    if (/Coupon.?Ersparnis/i.test(line)) {
      inCouponSection = true;
      continue;
    }
    const totalMatch = line.match(TOTAL_SAVINGS_LINE);
    if (totalMatch) {
      totalSavingsCents = parseAmountToCents(totalMatch[1]);
      inCouponSection = false;
      continue;
    }
    if (inCouponSection) {
      const couponMatch = line.match(COUPON_LINE);
      if (couponMatch) {
        coupons.push({ label: couponMatch[2].trim(), amountCents: parseAmountToCents(couponMatch[3]) });
      }
    }
  }
  return { totalSavingsCents, coupons };
}

// modules-src/penny/index.ts
var DISCOVERY_URL = "https://account.penny.de/realms/penny/.well-known/openid-configuration";
var CLIENT_ID = "pennyandroid";
var REDIRECT_URI = "https://www.penny.de/app/login";
var SCOPE = "openid profile email";
var API_BASE = "https://api.penny.de";
var MARKET_LIST_URL = "https://www.penny.de/.rest/market";
var MARKET_CACHE_TTL_MS = 24 * 60 * 60 * 1e3;
function decodeJwtPayload(jwt) {
  const payload = jwt.split(".")[1];
  if (!payload) throw new Error("Ung\xFCltiger JWT (kein Payload-Segment)");
  const json = Buffer.from(payload, "base64url").toString("utf8");
  return JSON.parse(json);
}
function createPennyModule(sdk) {
  let cachedDiscovery = null;
  async function getDiscovery() {
    if (cachedDiscovery) return cachedDiscovery;
    const { status, json } = await sdk.http.requestJson(DISCOVERY_URL);
    if (status !== 200 || !json.authorization_endpoint || !json.token_endpoint) {
      throw new Error(`PENNY-Discovery-Dokument nicht ladbar (Status ${status})`);
    }
    cachedDiscovery = json;
    return json;
  }
  let marketCache = null;
  async function getMarketIndex() {
    if (marketCache && Date.now() - marketCache.fetchedAt < MARKET_CACHE_TTL_MS) return marketCache.byMarketNumber;
    const { status, json } = await sdk.http.requestJson(MARKET_LIST_URL);
    if (status !== 200) throw new Error(`PENNY-Marktliste (${MARKET_LIST_URL}) antwortete mit Status ${status}`);
    const byMarketNumber = /* @__PURE__ */ new Map();
    for (const market of json) {
      if (!market.wawi || market.wawi.length < 4) continue;
      const marketNumber = market.wawi.slice(-4);
      const list = byMarketNumber.get(marketNumber) ?? [];
      list.push(market);
      byMarketNumber.set(marketNumber, list);
    }
    marketCache = { byMarketNumber, fetchedAt: Date.now() };
    return byMarketNumber;
  }
  async function resolveMarketNumber(marketNumber) {
    const padded = String(marketNumber).padStart(4, "0");
    try {
      const index = await getMarketIndex();
      const matches = index.get(padded);
      if (!matches || matches.length !== 1) return { name: `Markt ${marketNumber}` };
      const m = matches[0];
      return { name: m.marketName, street: m.streetWithHouseNumber, zipCode: m.zipCode, city: m.city };
    } catch {
      return { name: `Markt ${marketNumber}` };
    }
  }
  async function exchangeToken(tokenEndpoint, params, previousReweId) {
    const { status, json } = await sdk.http.requestJson(tokenEndpoint, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: sdk.http.formBody(params)
    });
    if (status !== 200 || !json.access_token) {
      throw new Error(`PENNY-Token-Endpoint antwortete mit Status ${status}`);
    }
    const claims = decodeJwtPayload(json.access_token);
    const reweId = claims.rewe_id ?? previousReweId;
    if (!reweId) throw new Error("Access-Token enth\xE4lt keinen rewe_id-Claim.");
    return {
      accessToken: json.access_token,
      refreshToken: json.refresh_token ?? params.refresh_token,
      expiresAt: Date.now() + json.expires_in * 1e3,
      reweId
    };
  }
  async function beginLogin() {
    const discovery = await getDiscovery();
    const codeVerifier = sdk.pkce.generateCodeVerifier();
    const codeChallenge = sdk.pkce.generateCodeChallenge(codeVerifier);
    const state = sdk.pkce.generateState();
    await sdk.pkce.saveState(state, codeVerifier);
    const url = new URL(discovery.authorization_endpoint);
    url.searchParams.set("client_id", CLIENT_ID);
    url.searchParams.set("redirect_uri", REDIRECT_URI);
    url.searchParams.set("response_type", "code");
    url.searchParams.set("scope", SCOPE);
    url.searchParams.set("state", state);
    url.searchParams.set("code_challenge", codeChallenge);
    url.searchParams.set("code_challenge_method", "S256");
    return { url: url.toString(), state };
  }
  async function completeLogin(input) {
    let code = input.code;
    let state = input.state;
    if (!code && input.redirectUrl) {
      const parsed = new URL(input.redirectUrl);
      code = parsed.searchParams.get("code") ?? void 0;
      state = parsed.searchParams.get("state") ?? void 0;
    }
    if (!code || !state) {
      throw new Error("Kein code/state in der eingef\xFCgten Redirect-URL gefunden.");
    }
    const pending = await sdk.pkce.consumeState(state);
    if (!pending) {
      throw new Error("Unbekannter oder abgelaufener Login-Versuch (state nicht gefunden) \u2014 bitte erneut starten.");
    }
    const discovery = await getDiscovery();
    return exchangeToken(discovery.token_endpoint, {
      grant_type: "authorization_code",
      client_id: CLIENT_ID,
      redirect_uri: REDIRECT_URI,
      code,
      code_verifier: pending.codeVerifier
    });
  }
  async function ensureFreshCredentials(creds) {
    const c = creds;
    if (c.expiresAt - Date.now() > 6e4) return c;
    const discovery = await getDiscovery();
    return exchangeToken(discovery.token_endpoint, { grant_type: "refresh_token", client_id: CLIENT_ID, refresh_token: c.refreshToken }, c.reweId);
  }
  function pennyHeaders(c) {
    return { Authorization: `Bearer ${c.accessToken}`, "correlation-id": randomUUID(), Accept: "application/json" };
  }
  async function normalizeMarket(market) {
    if (market === null || market === void 0) return null;
    if (typeof market === "string" || typeof market === "number") return resolveMarketNumber(market);
    if (!market.name && !market.street && !market.zipCode && !market.city) return null;
    return { name: market.name, street: market.street, zipCode: market.zipCode, city: market.city };
  }
  async function fetchReceipts(creds, knownIds) {
    const c = creds;
    const results = [];
    let page = 1;
    const objectsPerPage = 20;
    while (true) {
      const url = `${API_BASE}/api/tenants/penny/customers/${c.reweId}/ebons?page=${page}&objectsPerPage=${objectsPerPage}`;
      const { status, json } = await sdk.http.requestJson(url, { method: "GET", headers: pennyHeaders(c) });
      if (status !== 200) throw new Error(`PENNY /ebons antwortete mit Status ${status}`);
      let hitKnown = false;
      for (const item of json.items) {
        if (knownIds.has(item.id)) {
          hitKnown = true;
          break;
        }
        results.push({
          storeId: "penny",
          externalId: item.id,
          timestamp: Date.parse(item.timestamp),
          totalCents: item.totalPrice,
          market: await normalizeMarket(item.market),
          cancelled: item.cancelled,
          hasStructuredItems: false
        });
      }
      if (hitKnown || json.items.length === 0 || json.pagination.currentPage >= json.pagination.pageCount) break;
      page++;
    }
    return results;
  }
  async function fetchReceiptPdf(creds, externalId) {
    const c = creds;
    const url = `${API_BASE}/api/tenants/penny/customers/${c.reweId}/ebons/${externalId}/pdf`;
    const res = await sdk.http.rawRequest(url, { method: "GET", headers: { ...pennyHeaders(c), Accept: "application/pdf" } });
    if (res.status !== 200) return null;
    return res.body;
  }
  async function fetchReceiptItems(creds, externalId, pdf) {
    const buffer = pdf ?? await fetchReceiptPdf(creds, externalId);
    if (!buffer) return [];
    return parseReceiptItems(await sdk.pdf.extractLines(buffer));
  }
  async function fetchReceiptSavings(creds, externalId, pdf) {
    const buffer = pdf ?? await fetchReceiptPdf(creds, externalId);
    if (!buffer) return null;
    return parseSavings(await sdk.pdf.extractLines(buffer));
  }
  async function refreshMarketInfo(creds, externalId, pdf) {
    const buffer = pdf ?? await fetchReceiptPdf(creds, externalId);
    if (!buffer) return null;
    const lines = await sdk.pdf.extractLines(buffer);
    const marketNumber = parseMarketNumber(lines);
    if (!marketNumber) return null;
    return normalizeMarket(marketNumber);
  }
  return {
    beginLogin,
    completeLogin,
    ensureFreshCredentials,
    fetchReceipts,
    fetchReceiptPdf,
    fetchReceiptItems,
    fetchReceiptSavings,
    refreshMarketInfo
  };
}
export {
  createPennyModule as default
};
