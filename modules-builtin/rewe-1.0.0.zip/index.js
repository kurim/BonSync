// modules-src/rewe/index.ts
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

// modules-src/_shared/posParser.ts
function parseAmountToCents(raw) {
  const normalized = raw.replace(/\./g, "").replace(",", ".");
  return Math.round(parseFloat(normalized) * 100);
}
var INVISIBLE_CODEPOINTS = [
  173,
  // SOFT HYPHEN
  ...range(8203, 8207),
  // ZERO WIDTH SPACE/JOINER/NON-JOINER, LTR/RTL MARK
  ...range(8234, 8238),
  // Bidi-Einbettung (LRE/RLE/PDF/LRO/RLO)
  8288,
  // WORD JOINER
  ...range(8294, 8297),
  // Bidi-Isolate (LRI/RLI/FSI/PDI)
  ...range(65024, 65039),
  // VARIATION SELECTOR-1..16
  65279
  // ZERO WIDTH NO-BREAK SPACE / BOM
];
function range(from, to) {
  const out = [];
  for (let i = from; i <= to; i++) out.push(i);
  return out;
}
var INVISIBLE_CHARS = new RegExp(`[${INVISIBLE_CODEPOINTS.map((c) => `\\u${c.toString(16).padStart(4, "0")}`).join("")}]`, "g");
function normalizeLine(rawLine) {
  return rawLine.replace(INVISIBLE_CHARS, " ").replace(/€\s?/g, "").replace(/\s+/g, " ").trim();
}
var PRICE = String.raw`-?\d{1,3}(?:\.\d{3})*,\d{2}`;
var ARTICLE_LINE = new RegExp(`^(.+?)\\s+(${PRICE})\\s*(\\*)?\\s*([A-Z])\\s*(\\*)?$`);
var QTY_ONLY_LINE = new RegExp(`^(\\d+)\\s*Stk\\s*x\\s*(${PRICE})\\s*$`, "i");
var QTY_PREFIX = new RegExp(`^(\\d+)\\s*Stk\\s*x\\s*(${PRICE})$`, "i");
var QTY_PREFIX_LINE = new RegExp(`^(\\d+)X\\s+(.+?)\\s+(${PRICE})\\s+(${PRICE})\\s*(\\*)?\\s*([A-Z])\\s*(\\*)?$`, "i");
function parseReceiptItems(lines) {
  const items = [];
  for (const rawLine of lines) {
    const line = normalizeLine(rawLine);
    if (!line) continue;
    if (/^SUMME\b/i.test(line) || /^Geg\.\s/i.test(line) || /^UID\s*Nr\.?:/i.test(line) || /^Markt:/i.test(line) || /EUR\s*gespart$/i.test(line) || /Treuepunkt/i.test(line) || /^\d{2}\.\d{2}\.\d{4}\s+\d{2}:\d{2}\s+Bon-Nr\.?:/i.test(line) || /^[A-Z]=\s*\d/.test(line)) {
      continue;
    }
    const qtyPrefixLineMatch = line.match(QTY_PREFIX_LINE);
    if (qtyPrefixLineMatch) {
      items.push({
        name: qtyPrefixLineMatch[2].trim(),
        priceCents: parseAmountToCents(qtyPrefixLineMatch[4]),
        quantity: parseInt(qtyPrefixLineMatch[1], 10),
        unitPriceCents: parseAmountToCents(qtyPrefixLineMatch[3]),
        taxCode: qtyPrefixLineMatch[6],
        discountExcluded: Boolean(qtyPrefixLineMatch[5] || qtyPrefixLineMatch[7])
      });
      continue;
    }
    const articleMatch = line.match(ARTICLE_LINE);
    if (articleMatch) {
      const namePart = articleMatch[1].trim();
      const totalPriceCents = parseAmountToCents(articleMatch[2]);
      const taxCode = articleMatch[4];
      const discountExcluded = Boolean(articleMatch[3] || articleMatch[5]);
      const qtyPrefixMatch = namePart.match(QTY_PREFIX);
      const pending = items[items.length - 1];
      if (qtyPrefixMatch && pending && pending.priceCents === 0 && pending.quantity === void 0) {
        pending.quantity = parseInt(qtyPrefixMatch[1], 10);
        pending.unitPriceCents = parseAmountToCents(qtyPrefixMatch[2]);
        pending.priceCents = totalPriceCents;
        pending.taxCode = taxCode;
        pending.discountExcluded = discountExcluded;
      } else {
        items.push({ name: namePart, priceCents: totalPriceCents, taxCode, discountExcluded });
      }
      continue;
    }
    const qtyOnlyMatch = line.match(QTY_ONLY_LINE);
    if (qtyOnlyMatch) {
      const prev = items[items.length - 1];
      if (prev && prev.priceCents !== 0 && prev.quantity === void 0) {
        prev.quantity = parseInt(qtyOnlyMatch[1], 10);
        prev.unitPriceCents = parseAmountToCents(qtyOnlyMatch[2]);
      }
      continue;
    }
    if (line.length > 1) {
      items.push({ name: line, priceCents: 0 });
    }
  }
  return items.filter((i) => i.priceCents !== 0 || i.quantity !== void 0);
}
var ZIP_CITY_LINE = /^(\d{5})\s+(.+)$/;
function parseMarketHeader(lines) {
  if (lines.length < 3) return {};
  const name = normalizeLine(lines[0]);
  const street = normalizeLine(lines[1]);
  const zipCityMatch = normalizeLine(lines[2]).match(ZIP_CITY_LINE);
  if (!name || !street || !zipCityMatch) return {};
  return { name, street, zipCode: zipCityMatch[1], city: zipCityMatch[2] };
}
var TOTAL_SAVINGS_LINE = new RegExp(`(${PRICE})\\s*(?:EUR)?\\s*gespart`, "i");
var COUPON_LINE = new RegExp(`^(\\d{6,})\\s+(.+?)\\s+(${PRICE})$`);
function parseSavings(lines) {
  let totalSavingsCents = null;
  const coupons = [];
  let inCouponSection = false;
  for (const rawLine of lines) {
    const line = normalizeLine(rawLine);
    if (!line) continue;
    if (/Coupon.?Ersparnis/i.test(line)) {
      inCouponSection = true;
      continue;
    }
    const totalMatch = line.match(TOTAL_SAVINGS_LINE);
    if (totalMatch) {
      totalSavingsCents = parseAmountToCents(totalMatch[1]);
      inCouponSection = false;
      continue;
    }
    if (inCouponSection) {
      const couponMatch = line.match(COUPON_LINE);
      if (couponMatch) {
        coupons.push({ label: couponMatch[2].trim(), amountCents: parseAmountToCents(couponMatch[3]) });
      }
    }
  }
  return { totalSavingsCents, coupons };
}

// modules-src/rewe/index.ts
var MODULE_DIR = dirname(fileURLToPath(import.meta.url));
var AUTHORIZE_ENDPOINT = "https://account.rewe.de/realms/sso/protocol/openid-connect/auth";
var TOKEN_ENDPOINT = "https://account.rewe.de/realms/sso/protocol/openid-connect/token";
var CLIENT_ID = "reweandroid";
var REDIRECT_URI = "de.rewe.app.mobile://redirect";
var SCOPE = "openid email offline_access";
var API_BASE = "https://mobile-clients-api.rewe.de";
var USER_AGENT = "REWE-Mobile-Client/3.17.1.32270 Android/11 Phone/Google_sdk_gphone_x86_64";
function createReweModule(sdk) {
  let cachedTls = null;
  function mtlsOptions() {
    if (cachedTls) return cachedTls;
    const dir = process.env.REWE_CERT_DIR ?? MODULE_DIR;
    cachedTls = {
      cert: readFileSync(join(dir, "client.pem")),
      key: readFileSync(join(dir, "client.key"))
    };
    return cachedTls;
  }
  async function exchangeToken(params) {
    const { status, json } = await sdk.http.requestJson(TOKEN_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded", "User-Agent": USER_AGENT },
      body: sdk.http.formBody(params)
    });
    if (status !== 200 || !json.access_token) {
      throw new Error(`REWE-Token-Endpoint antwortete mit Status ${status}`);
    }
    return {
      accessToken: json.access_token,
      refreshToken: json.refresh_token,
      expiresAt: Date.now() + json.expires_in * 1e3
    };
  }
  async function beginLogin() {
    const codeVerifier = sdk.pkce.generateCodeVerifier();
    const codeChallenge = sdk.pkce.generateCodeChallenge(codeVerifier);
    const state = sdk.pkce.generateState();
    await sdk.pkce.saveState(state, codeVerifier);
    const url = new URL(AUTHORIZE_ENDPOINT);
    url.searchParams.set("client_id", CLIENT_ID);
    url.searchParams.set("redirect_uri", REDIRECT_URI);
    url.searchParams.set("response_type", "code");
    url.searchParams.set("scope", SCOPE);
    url.searchParams.set("state", state);
    url.searchParams.set("code_challenge", codeChallenge);
    url.searchParams.set("code_challenge_method", "S256");
    return { url: url.toString(), state };
  }
  async function completeLogin(input) {
    let code = input.code;
    let state = input.state;
    if (!code && input.redirectUrl) {
      const parsed = new URL(input.redirectUrl.replace("de.rewe.app.mobile://redirect", "https://placeholder"));
      code = parsed.searchParams.get("code") ?? void 0;
      state = parsed.searchParams.get("state") ?? void 0;
    }
    if (!code || !state) {
      throw new Error("Kein code/state in der eingef\xFCgten Redirect-URL gefunden.");
    }
    const pending = await sdk.pkce.consumeState(state);
    if (!pending) {
      throw new Error("Unbekannter oder abgelaufener Login-Versuch (state nicht gefunden) \u2014 bitte erneut starten.");
    }
    return exchangeToken({
      grant_type: "authorization_code",
      client_id: CLIENT_ID,
      redirect_uri: REDIRECT_URI,
      code,
      code_verifier: pending.codeVerifier
    });
  }
  async function ensureFreshCredentials(creds) {
    const c = creds;
    if (c.expiresAt - Date.now() > 6e4) return c;
    return exchangeToken({ grant_type: "refresh_token", client_id: CLIENT_ID, refresh_token: c.refreshToken });
  }
  async function fetchReceipts(creds, knownIds) {
    const c = creds;
    const results = [];
    let page = 1;
    const objectsPerPage = 50;
    while (true) {
      const url = `${API_BASE}/api/ebons?page=${page}&objectsPerPage=${objectsPerPage}`;
      const { status, json } = await sdk.http.requestJson(url, {
        method: "GET",
        headers: { Authorization: `Bearer ${c.accessToken}`, "User-Agent": USER_AGENT, Accept: "application/json" },
        tls: mtlsOptions()
      });
      if (status !== 200) throw new Error(`REWE /api/ebons antwortete mit Status ${status}`);
      const { items, pagination } = json.data.getEbons;
      let hitKnown = false;
      for (const item of items) {
        if (knownIds.has(item.receiptId)) {
          hitKnown = true;
          break;
        }
        results.push({
          storeId: "rewe",
          externalId: item.receiptId,
          timestamp: Date.parse(item.receiptTimestamp),
          totalCents: item.receiptTotalPrice,
          market: item.market ? { name: item.market.name, street: item.market.street, zipCode: item.market.zipCode, city: item.market.city } : null,
          cancelled: item.cancelled,
          hasStructuredItems: false
        });
      }
      if (hitKnown || items.length === 0 || pagination.currentPage >= pagination.pageCount) break;
      page++;
    }
    return results;
  }
  async function fetchReceiptPdf(creds, externalId) {
    const c = creds;
    const url = `${API_BASE}/api/receipts/${externalId}/pdf`;
    const res = await sdk.http.rawRequest(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${c.accessToken}`, "User-Agent": USER_AGENT, Accept: "application/pdf" },
      tls: mtlsOptions()
    });
    if (res.status !== 200) return null;
    return res.body;
  }
  async function fetchReceiptItems(creds, externalId, pdf) {
    const buffer = pdf ?? await fetchReceiptPdf(creds, externalId);
    if (!buffer) return [];
    return parseReceiptItems(await sdk.pdf.extractLines(buffer));
  }
  async function fetchReceiptSavings(creds, externalId, pdf) {
    const buffer = pdf ?? await fetchReceiptPdf(creds, externalId);
    if (!buffer) return null;
    return parseSavings(await sdk.pdf.extractLines(buffer));
  }
  async function refreshMarketInfo(creds, externalId, pdf) {
    const buffer = pdf ?? await fetchReceiptPdf(creds, externalId);
    if (!buffer) return null;
    const lines = await sdk.pdf.extractLines(buffer);
    const header = parseMarketHeader(lines);
    if (!header.name) return null;
    return { name: header.name, street: header.street, zipCode: header.zipCode, city: header.city };
  }
  return {
    beginLogin,
    completeLogin,
    ensureFreshCredentials,
    fetchReceipts,
    fetchReceiptPdf,
    fetchReceiptItems,
    fetchReceiptSavings,
    refreshMarketInfo
  };
}
export {
  createReweModule as default
};
