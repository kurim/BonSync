// modules-src/lidl/htmlToLines.ts
var BLOCK_TAGS = /<\/(tr|div|p|li|h[1-6])>|<br\s*\/?>/gi;
var ANY_TAG = /<[^>]+>/g;
var ENTITY_MAP = {
  nbsp: " ",
  amp: "&",
  lt: "<",
  gt: ">",
  quot: '"',
  apos: "'",
  euro: "\u20AC"
};
function decodeEntities(text) {
  return text.replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (match, entity) => {
    if (entity[0] === "#") {
      const code = entity[1] === "x" || entity[1] === "X" ? parseInt(entity.slice(2), 16) : parseInt(entity.slice(1), 10);
      return Number.isFinite(code) ? String.fromCodePoint(code) : match;
    }
    return ENTITY_MAP[entity.toLowerCase()] ?? match;
  });
}
function htmlToLines(html) {
  const withoutScripts = html.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "");
  const withBreaks = withoutScripts.replace(BLOCK_TAGS, "\n");
  const textOnly = decodeEntities(withBreaks.replace(ANY_TAG, ""));
  return textOnly.split("\n").map((line) => line.replace(/\s+/g, " ").trim()).filter((line) => line.length > 0);
}

// modules-src/lidl/parser.ts
function parseAmountToCents(raw) {
  const normalized = raw.replace(/\./g, "").replace(",", ".");
  return Math.round(parseFloat(normalized) * 100);
}
var INVISIBLE_CODEPOINTS = [
  173,
  // SOFT HYPHEN
  ...range(8203, 8207),
  // ZERO WIDTH SPACE/JOINER/NON-JOINER, LTR/RTL MARK
  ...range(8234, 8238),
  // Bidi-Einbettung (LRE/RLE/PDF/LRO/RLO)
  8288,
  // WORD JOINER
  ...range(8294, 8297),
  // Bidi-Isolate (LRI/RLI/FSI/PDI)
  ...range(65024, 65039),
  // VARIATION SELECTOR-1..16
  65279
  // ZERO WIDTH NO-BREAK SPACE / BOM
];
function range(from, to) {
  const out = [];
  for (let i = from; i <= to; i++) out.push(i);
  return out;
}
var INVISIBLE_CHARS = new RegExp(`[${INVISIBLE_CODEPOINTS.map((c) => `\\u${c.toString(16).padStart(4, "0")}`).join("")}]`, "g");
function normalizeLine(rawLine) {
  return rawLine.replace(INVISIBLE_CHARS, " ").replace(/€\s?/g, "").replace(/\s+/g, " ").trim();
}
var PRICE = String.raw`-?\d{1,3}(?:\.\d{3})*,\d{2}`;
var ARTICLE_LINE = new RegExp(`^(.+?)\\s+(${PRICE})\\s*(\\*)?\\s*([A-Z])\\s*(\\*)?$`);
var QTY_ONLY_LINE = new RegExp(`^(\\d+)\\s*Stk\\s*x\\s*(${PRICE})\\s*$`, "i");
var QTY_PREFIX = new RegExp(`^(\\d+)\\s*Stk\\s*x\\s*(${PRICE})$`, "i");
var QTY_PREFIX_LINE = new RegExp(`^(\\d+)X\\s+(.+?)\\s+(${PRICE})\\s+(${PRICE})\\s*(\\*)?\\s*([A-Z])\\s*(\\*)?$`, "i");
var LIDL_ARTICLE_LINE = new RegExp(`^(.+?)\\s+(${PRICE})\\s*x\\s*(\\d+)\\s+(${PRICE})\\s*(\\*)?\\s*([A-Z])\\s*(\\*)?$`, "i");
function parseReceiptItems(lines) {
  const items = [];
  for (const rawLine of lines) {
    const line = normalizeLine(rawLine);
    if (!line) continue;
    if (/^SUMME\b/i.test(line) || /^Geg\.\s/i.test(line) || /^UID\s*Nr\.?:/i.test(line) || /^Markt:/i.test(line) || /EUR\s*gespart$/i.test(line) || /Treuepunkt/i.test(line) || /^\d{2}\.\d{2}\.\d{4}\s+\d{2}:\d{2}\s+Bon-Nr\.?:/i.test(line) || /^[A-Z]=\s*\d/.test(line)) {
      continue;
    }
    const qtyPrefixLineMatch = line.match(QTY_PREFIX_LINE);
    if (qtyPrefixLineMatch) {
      items.push({
        name: qtyPrefixLineMatch[2].trim(),
        priceCents: parseAmountToCents(qtyPrefixLineMatch[4]),
        quantity: parseInt(qtyPrefixLineMatch[1], 10),
        unitPriceCents: parseAmountToCents(qtyPrefixLineMatch[3]),
        taxCode: qtyPrefixLineMatch[6],
        discountExcluded: Boolean(qtyPrefixLineMatch[5] || qtyPrefixLineMatch[7])
      });
      continue;
    }
    const lidlMatch = line.match(LIDL_ARTICLE_LINE);
    if (lidlMatch) {
      items.push({
        name: lidlMatch[1].trim(),
        priceCents: parseAmountToCents(lidlMatch[4]),
        quantity: parseInt(lidlMatch[3], 10),
        unitPriceCents: parseAmountToCents(lidlMatch[2]),
        taxCode: lidlMatch[6],
        discountExcluded: Boolean(lidlMatch[5] || lidlMatch[7])
      });
      continue;
    }
    const articleMatch = line.match(ARTICLE_LINE);
    if (articleMatch) {
      const namePart = articleMatch[1].trim();
      const totalPriceCents = parseAmountToCents(articleMatch[2]);
      const taxCode = articleMatch[4];
      const discountExcluded = Boolean(articleMatch[3] || articleMatch[5]);
      const qtyPrefixMatch = namePart.match(QTY_PREFIX);
      const pending = items[items.length - 1];
      if (qtyPrefixMatch && pending && pending.priceCents === 0 && pending.quantity === void 0) {
        pending.quantity = parseInt(qtyPrefixMatch[1], 10);
        pending.unitPriceCents = parseAmountToCents(qtyPrefixMatch[2]);
        pending.priceCents = totalPriceCents;
        pending.taxCode = taxCode;
        pending.discountExcluded = discountExcluded;
      } else {
        items.push({ name: namePart, priceCents: totalPriceCents, taxCode, discountExcluded });
      }
      continue;
    }
    const qtyOnlyMatch = line.match(QTY_ONLY_LINE);
    if (qtyOnlyMatch) {
      const prev = items[items.length - 1];
      if (prev && prev.priceCents !== 0 && prev.quantity === void 0) {
        prev.quantity = parseInt(qtyOnlyMatch[1], 10);
        prev.unitPriceCents = parseAmountToCents(qtyOnlyMatch[2]);
      }
      continue;
    }
    if (line.length > 1) {
      items.push({ name: line, priceCents: 0 });
    }
  }
  return items.filter((i) => i.priceCents !== 0 || i.quantity !== void 0);
}
var TOTAL_SAVINGS_LINE = new RegExp(`(${PRICE})\\s*(?:EUR)?\\s*gespart`, "i");
var COUPON_LINE = new RegExp(`^(\\d{6,})\\s+(.+?)\\s+(${PRICE})$`);
function parseSavings(lines) {
  let totalSavingsCents = null;
  const coupons = [];
  let inCouponSection = false;
  for (const rawLine of lines) {
    const line = normalizeLine(rawLine);
    if (!line) continue;
    if (/Coupon.?Ersparnis/i.test(line)) {
      inCouponSection = true;
      continue;
    }
    const totalMatch = line.match(TOTAL_SAVINGS_LINE);
    if (totalMatch) {
      totalSavingsCents = parseAmountToCents(totalMatch[1]);
      inCouponSection = false;
      continue;
    }
    if (inCouponSection) {
      const couponMatch = line.match(COUPON_LINE);
      if (couponMatch) {
        coupons.push({ label: couponMatch[2].trim(), amountCents: parseAmountToCents(couponMatch[3]) });
      }
    }
  }
  return { totalSavingsCents, coupons };
}

// modules-src/lidl/index.ts
var AUTHORIZE_ENDPOINT = "https://accounts.lidl.com/connect/authorize";
var TOKEN_ENDPOINT = "https://accounts.lidl.com/connect/token";
var CLIENT_ID = "LidlPlusNativeClient";
var CLIENT_SECRET = "secret";
var REDIRECT_URI = "com.lidlplus.app://callback";
var SCOPE = "openid profile offline_access lpprofile lpapis";
var COUNTRY = "DE";
var LANGUAGE = "de-DE";
var TICKETS_API = "https://tickets.lidlplus.com/api";
var APP_VERSION = "17.9.3";
var APP_ID = "com.lidl.eci.lidlplus";
function basicAuthHeader() {
  return "Basic " + Buffer.from(`${CLIENT_ID}:${CLIENT_SECRET}`).toString("base64");
}
function marketName(name) {
  if (!name) return name;
  return name.startsWith("Lidl") ? name : `Lidl ${name}`;
}
function createLidlModule(sdk) {
  async function exchangeToken(params) {
    const { status, json } = await sdk.http.requestJson(TOKEN_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded", Authorization: basicAuthHeader() },
      body: sdk.http.formBody(params)
    });
    if (status !== 200 || !json.access_token) {
      throw new Error(`LIDL-Token-Endpoint antwortete mit Status ${status}`);
    }
    return {
      accessToken: json.access_token,
      refreshToken: json.refresh_token,
      expiresAt: Date.now() + json.expires_in * 1e3
    };
  }
  async function beginLogin() {
    const codeVerifier = sdk.pkce.generateCodeVerifier();
    const codeChallenge = sdk.pkce.generateCodeChallenge(codeVerifier);
    const state = sdk.pkce.generateState();
    await sdk.pkce.saveState(state, codeVerifier);
    const url = new URL(AUTHORIZE_ENDPOINT);
    url.searchParams.set("client_id", CLIENT_ID);
    url.searchParams.set("redirect_uri", REDIRECT_URI);
    url.searchParams.set("response_type", "code");
    url.searchParams.set("scope", SCOPE);
    url.searchParams.set("state", state);
    url.searchParams.set("nonce", sdk.pkce.generateState());
    url.searchParams.set("code_challenge", codeChallenge);
    url.searchParams.set("code_challenge_method", "S256");
    url.searchParams.set("Country", COUNTRY);
    url.searchParams.set("language", LANGUAGE);
    url.searchParams.set("force", "false");
    url.searchParams.set("track", "false");
    return { url: url.toString(), state };
  }
  async function completeLogin(input) {
    let code = input.code;
    let state = input.state;
    if (!code && input.redirectUrl) {
      const parsed = new URL(input.redirectUrl.replace("com.lidlplus.app://callback", "https://placeholder"));
      code = parsed.searchParams.get("code") ?? void 0;
      state = parsed.searchParams.get("state") ?? void 0;
    }
    if (!code || !state) {
      throw new Error("Kein code/state in der eingef\xFCgten Redirect-URL gefunden.");
    }
    const pending = await sdk.pkce.consumeState(state);
    if (!pending) {
      throw new Error("Unbekannter oder abgelaufener Login-Versuch (state nicht gefunden) \u2014 bitte erneut starten.");
    }
    return exchangeToken({ grant_type: "authorization_code", code, redirect_uri: REDIRECT_URI, code_verifier: pending.codeVerifier });
  }
  async function ensureFreshCredentials(creds) {
    const c = creds;
    if (c.expiresAt - Date.now() > 6e4) return c;
    return exchangeToken({ grant_type: "refresh_token", refresh_token: c.refreshToken });
  }
  function ticketHeaders(c) {
    return {
      Authorization: `Bearer ${c.accessToken}`,
      Accept: "application/json",
      "App-Version": APP_VERSION,
      "Operating-System": "Android",
      App: APP_ID,
      "Accept-Language": "de"
    };
  }
  async function fetchReceipts(creds, knownIds) {
    const c = creds;
    const results = [];
    let skip = 0;
    const take = 50;
    while (true) {
      const url = `${TICKETS_API}/v2/${COUNTRY}/tickets?skip=${skip}&take=${take}`;
      const { status, json } = await sdk.http.requestJson(url, { method: "GET", headers: ticketHeaders(c) });
      if (status !== 200) throw new Error(`LIDL /tickets antwortete mit Status ${status}`);
      const tickets = Array.isArray(json?.tickets) ? json.tickets : [];
      let hitKnown = false;
      for (const item of tickets) {
        if (knownIds.has(item.id)) {
          hitKnown = true;
          break;
        }
        results.push({
          storeId: "lidl",
          externalId: item.id,
          timestamp: Date.parse(item.date),
          totalCents: Math.round(item.totalAmount * 100),
          market: null,
          cancelled: false,
          hasStructuredItems: false
        });
      }
      const fetchedSoFar = skip + tickets.length;
      if (hitKnown || tickets.length === 0 || fetchedSoFar >= json.totalCount) break;
      skip = fetchedSoFar;
    }
    return results;
  }
  const ticketDetailCache = /* @__PURE__ */ new Map();
  async function fetchTicketDetail(c, externalId) {
    const cached = ticketDetailCache.get(externalId);
    if (cached) return cached;
    const url = `${TICKETS_API}/v3/${COUNTRY}/tickets/${externalId}`;
    const { status, json } = await sdk.http.requestJson(url, { method: "GET", headers: ticketHeaders(c) });
    if (status !== 200) throw new Error(`LIDL /tickets/{id} antwortete mit Status ${status}`);
    ticketDetailCache.set(externalId, json);
    return json;
  }
  async function fetchReceiptPdf(creds, externalId) {
    const c = creds;
    const detail = await fetchTicketDetail(c, externalId);
    if (!detail.htmlPrintedReceipt) return null;
    return sdk.html.toPdf(detail.htmlPrintedReceipt);
  }
  async function fetchReceiptItems(creds, externalId) {
    const c = creds;
    const detail = await fetchTicketDetail(c, externalId);
    if (!detail.htmlPrintedReceipt) return [];
    return parseReceiptItems(htmlToLines(detail.htmlPrintedReceipt));
  }
  async function fetchReceiptSavings(creds, externalId) {
    const c = creds;
    const detail = await fetchTicketDetail(c, externalId);
    if (!detail.htmlPrintedReceipt) return null;
    return parseSavings(htmlToLines(detail.htmlPrintedReceipt));
  }
  async function refreshMarketInfo(creds, externalId) {
    const c = creds;
    const detail = await fetchTicketDetail(c, externalId);
    if (!detail.store) return null;
    const { name, address, postalCode, locality } = detail.store;
    if (!name && !address && !postalCode && !locality) return null;
    return { name: marketName(name), street: address, zipCode: postalCode, city: locality };
  }
  return {
    beginLogin,
    completeLogin,
    ensureFreshCredentials,
    fetchReceipts,
    fetchReceiptPdf,
    fetchReceiptItems,
    fetchReceiptSavings,
    refreshMarketInfo
  };
}
export {
  createLidlModule as default
};
