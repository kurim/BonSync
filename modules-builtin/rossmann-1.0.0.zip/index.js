// modules-src/rossmann/index.ts
import { randomUUID } from "node:crypto";

// modules-src/_shared/posParser.ts
function parseAmountToCents(raw) {
  const normalized = raw.replace(/\./g, "").replace(",", ".");
  return Math.round(parseFloat(normalized) * 100);
}
var INVISIBLE_CODEPOINTS = [
  173,
  // SOFT HYPHEN
  ...range(8203, 8207),
  // ZERO WIDTH SPACE/JOINER/NON-JOINER, LTR/RTL MARK
  ...range(8234, 8238),
  // Bidi-Einbettung (LRE/RLE/PDF/LRO/RLO)
  8288,
  // WORD JOINER
  ...range(8294, 8297),
  // Bidi-Isolate (LRI/RLI/FSI/PDI)
  ...range(65024, 65039),
  // VARIATION SELECTOR-1..16
  65279
  // ZERO WIDTH NO-BREAK SPACE / BOM
];
function range(from, to) {
  const out = [];
  for (let i = from; i <= to; i++) out.push(i);
  return out;
}
var INVISIBLE_CHARS = new RegExp(`[${INVISIBLE_CODEPOINTS.map((c) => `\\u${c.toString(16).padStart(4, "0")}`).join("")}]`, "g");
function normalizeLine(rawLine) {
  return rawLine.replace(INVISIBLE_CHARS, " ").replace(/€\s?/g, "").replace(/\s+/g, " ").trim();
}
var PRICE = String.raw`-?\d{1,3}(?:\.\d{3})*,\d{2}`;
var ARTICLE_LINE = new RegExp(`^(.+?)\\s+(${PRICE})\\s*(\\*)?\\s*([A-Z])\\s*(\\*)?$`);
var QTY_ONLY_LINE = new RegExp(`^(\\d+)\\s*Stk\\s*x\\s*(${PRICE})\\s*$`, "i");
var QTY_PREFIX = new RegExp(`^(\\d+)\\s*Stk\\s*x\\s*(${PRICE})$`, "i");
var QTY_PREFIX_LINE = new RegExp(`^(\\d+)X\\s+(.+?)\\s+(${PRICE})\\s+(${PRICE})\\s*(\\*)?\\s*([A-Z])\\s*(\\*)?$`, "i");
function parseReceiptItems(lines) {
  const items = [];
  for (const rawLine of lines) {
    const line = normalizeLine(rawLine);
    if (!line) continue;
    if (/^SUMME\b/i.test(line) || /^Geg\.\s/i.test(line) || /^UID\s*Nr\.?:/i.test(line) || /^Markt:/i.test(line) || /EUR\s*gespart$/i.test(line) || /Treuepunkt/i.test(line) || /^\d{2}\.\d{2}\.\d{4}\s+\d{2}:\d{2}\s+Bon-Nr\.?:/i.test(line) || /^[A-Z]=\s*\d/.test(line)) {
      continue;
    }
    const qtyPrefixLineMatch = line.match(QTY_PREFIX_LINE);
    if (qtyPrefixLineMatch) {
      items.push({
        name: qtyPrefixLineMatch[2].trim(),
        priceCents: parseAmountToCents(qtyPrefixLineMatch[4]),
        quantity: parseInt(qtyPrefixLineMatch[1], 10),
        unitPriceCents: parseAmountToCents(qtyPrefixLineMatch[3]),
        taxCode: qtyPrefixLineMatch[6],
        discountExcluded: Boolean(qtyPrefixLineMatch[5] || qtyPrefixLineMatch[7])
      });
      continue;
    }
    const articleMatch = line.match(ARTICLE_LINE);
    if (articleMatch) {
      const namePart = articleMatch[1].trim();
      const totalPriceCents = parseAmountToCents(articleMatch[2]);
      const taxCode = articleMatch[4];
      const discountExcluded = Boolean(articleMatch[3] || articleMatch[5]);
      const qtyPrefixMatch = namePart.match(QTY_PREFIX);
      const pending = items[items.length - 1];
      if (qtyPrefixMatch && pending && pending.priceCents === 0 && pending.quantity === void 0) {
        pending.quantity = parseInt(qtyPrefixMatch[1], 10);
        pending.unitPriceCents = parseAmountToCents(qtyPrefixMatch[2]);
        pending.priceCents = totalPriceCents;
        pending.taxCode = taxCode;
        pending.discountExcluded = discountExcluded;
      } else {
        items.push({ name: namePart, priceCents: totalPriceCents, taxCode, discountExcluded });
      }
      continue;
    }
    const qtyOnlyMatch = line.match(QTY_ONLY_LINE);
    if (qtyOnlyMatch) {
      const prev = items[items.length - 1];
      if (prev && prev.priceCents !== 0 && prev.quantity === void 0) {
        prev.quantity = parseInt(qtyOnlyMatch[1], 10);
        prev.unitPriceCents = parseAmountToCents(qtyOnlyMatch[2]);
      }
      continue;
    }
    if (line.length > 1) {
      items.push({ name: line, priceCents: 0 });
    }
  }
  return items.filter((i) => i.priceCents !== 0 || i.quantity !== void 0);
}
var TOTAL_SAVINGS_LINE = new RegExp(`(${PRICE})\\s*(?:EUR)?\\s*gespart`, "i");
var COUPON_LINE = new RegExp(`^(\\d{6,})\\s+(.+?)\\s+(${PRICE})$`);
function parseSavings(lines) {
  let totalSavingsCents = null;
  const coupons = [];
  let inCouponSection = false;
  for (const rawLine of lines) {
    const line = normalizeLine(rawLine);
    if (!line) continue;
    if (/Coupon.?Ersparnis/i.test(line)) {
      inCouponSection = true;
      continue;
    }
    const totalMatch = line.match(TOTAL_SAVINGS_LINE);
    if (totalMatch) {
      totalSavingsCents = parseAmountToCents(totalMatch[1]);
      inCouponSection = false;
      continue;
    }
    if (inCouponSection) {
      const couponMatch = line.match(COUPON_LINE);
      if (couponMatch) {
        coupons.push({ label: couponMatch[2].trim(), amountCents: parseAmountToCents(couponMatch[3]) });
      }
    }
  }
  return { totalSavingsCents, coupons };
}

// modules-src/rossmann/index.ts
var ACCOUNT_API = "https://rsmappapi.rossmann.net/account.ws";
var ANYBILL_API = "https://app.anybill.de/api/v4";
var API_KEY = "rqYCy0y0BH5+8ZU5";
var APP_VERSION = "5.11.1";
var BUILD_NUMBER = "421000110";
var ANDROID_ID = "a1b2c3d4e5f6a7b8";
var REUSE_IDENTIFIER = "b8a7f6e5d4c3b2a1";
var RECEIPT_LIST_CACHE_TTL_MS = 5 * 60 * 1e3;
function describeError(status, json) {
  const body = typeof json === "object" && json !== null ? JSON.stringify(json) : String(json);
  return `Status ${status}: ${body.slice(0, 500)}`;
}
function accountHeaders(extra) {
  return {
    "x-api-key": API_KEY,
    "x-correlation-id": randomUUID(),
    "App-Version": APP_VERSION,
    "Build-Number": BUILD_NUMBER,
    Platform: "android",
    "Platform-Version": "14",
    "Android-Id": ANDROID_ID,
    "Reuse-Identifier": REUSE_IDENTIFIER,
    "Build-Serial": "unknown",
    "User-Agent": "okhttp/5.3.2",
    // ohne exakt diesen UA blockt Fastly mit 406
    ...extra
  };
}
function sellerToMarket(seller) {
  if (!seller?.name) return null;
  const name = seller.name.startsWith("Rossmann") ? seller.name : `Rossmann ${seller.name}`;
  return { name, street: seller.address?.street, city: seller.address?.city };
}
function createRossmannModule(sdk) {
  async function loginWithCredentials(fields) {
    const { email, password } = fields;
    if (!email || !password) throw new Error("E-Mail und Passwort werden ben\xF6tigt.");
    const { status, json } = await sdk.http.requestJson(`${ACCOUNT_API}/v2/accounts/login`, {
      method: "POST",
      headers: { ...accountHeaders(), "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    if (status !== 200 || !json.accountHash) {
      throw new Error(`ROSSMANN-Login fehlgeschlagen \u2014 ${describeError(status, json)}`);
    }
    const creds = { accountId: json.accountId, accountHash: json.accountHash };
    return creds;
  }
  async function ensureFreshCredentials(creds) {
    return creds;
  }
  const anybillTokenCache = /* @__PURE__ */ new Map();
  async function getAnybillToken(creds) {
    const cached = anybillTokenCache.get(creds.accountHash);
    if (cached && cached.expiresAt - Date.now() > 6e4) return cached.accessToken;
    const { status, json } = await sdk.http.requestJson(`${ACCOUNT_API}/v2/accounts/${creds.accountId}/receipt/auth`, {
      method: "GET",
      headers: accountHeaders({ "Account-Hash": creds.accountHash })
    });
    if (status !== 200 || !json.accessToken) {
      throw new Error(`ROSSMANN anybill-Token-Endpoint fehlgeschlagen \u2014 ${describeError(status, json)}`);
    }
    anybillTokenCache.set(creds.accountHash, { accessToken: json.accessToken, expiresAt: Date.now() + json.expiresIn * 1e3 });
    return json.accessToken;
  }
  const receiptListCache = /* @__PURE__ */ new Map();
  async function fetchReceiptList(creds, take) {
    const accessToken = await getAnybillToken(creds);
    const url = `${ANYBILL_API}/receipt?take=${take}&orderBy=Date&orderByDirection=Descending`;
    const { status, json } = await sdk.http.requestJson(url, { method: "GET", headers: { Authorization: `Bearer ${accessToken}` } });
    if (status !== 200) throw new Error(`ROSSMANN /receipt fehlgeschlagen \u2014 ${describeError(status, json)}`);
    receiptListCache.set(creds.accountHash, { byId: new Map(json.map((r) => [r.id, r])), fetchedAt: Date.now() });
    return json;
  }
  async function fetchReceipts(creds, knownIds) {
    const c = creds;
    const take = 100;
    const items = await fetchReceiptList(c, take);
    const results = [];
    for (const item of items) {
      if (knownIds.has(item.id)) break;
      results.push({
        storeId: "rossmann",
        externalId: item.id,
        timestamp: Date.parse(item.head.date),
        totalCents: Math.round(item.data.fullAmountInclVat * 100),
        market: sellerToMarket(item.head.seller),
        cancelled: false,
        hasStructuredItems: true
      });
    }
    return results;
  }
  async function fetchReceiptPdf(creds, externalId) {
    const c = creds;
    const accessToken = await getAnybillToken(c);
    const url = `${ANYBILL_API}/receipt/${externalId}/pdf?IsPrintedVersion=false&IncludeReturnReceipts=false`;
    const res = await sdk.http.rawRequest(url, { method: "GET", headers: { Authorization: `Bearer ${accessToken}`, Accept: "application/pdf" } });
    if (res.status !== 200) return null;
    return res.body;
  }
  async function fetchReceiptItems(creds, externalId, pdf) {
    const c = creds;
    let cached = receiptListCache.get(c.accountHash);
    if (!cached || Date.now() - cached.fetchedAt > RECEIPT_LIST_CACHE_TTL_MS || !cached.byId.has(externalId)) {
      await fetchReceiptList(c, 100);
      cached = receiptListCache.get(c.accountHash);
    }
    const receipt = cached?.byId.get(externalId);
    if (!receipt?.data.lines) return [];
    const items = receipt.data.lines.map((line) => ({
      name: line.text,
      priceCents: Math.round(line.fullAmountInclVat * 100),
      quantity: line.item?.quantity,
      unitPriceCents: line.item?.pricePerUnit != null ? Math.round(line.item.pricePerUnit * 100) : void 0
    }));
    try {
      const pdfBuffer = pdf ?? await fetchReceiptPdf(creds, externalId);
      if (pdfBuffer) {
        const pdfItems = parseReceiptItems(await sdk.pdf.extractLines(pdfBuffer));
        if (pdfItems.length === items.length) {
          items.forEach((item, i) => {
            item.taxCode = pdfItems[i].taxCode;
            item.discountExcluded = pdfItems[i].discountExcluded;
          });
        } else {
          const byPriceCents = /* @__PURE__ */ new Map();
          for (const pi of pdfItems) {
            const list = byPriceCents.get(pi.priceCents) ?? [];
            list.push(pi);
            byPriceCents.set(pi.priceCents, list);
          }
          for (const item of items) {
            const candidates = byPriceCents.get(item.priceCents);
            const match = candidates?.shift();
            if (match) {
              item.taxCode = match.taxCode;
              item.discountExcluded = match.discountExcluded;
            }
          }
        }
      }
    } catch {
    }
    return items;
  }
  async function fetchReceiptSavings(creds, externalId, pdf) {
    const buffer = pdf ?? await fetchReceiptPdf(creds, externalId);
    if (!buffer) return null;
    return parseSavings(await sdk.pdf.extractLines(buffer));
  }
  async function refreshMarketInfo(creds, externalId) {
    const c = creds;
    let cached = receiptListCache.get(c.accountHash);
    if (!cached || Date.now() - cached.fetchedAt > RECEIPT_LIST_CACHE_TTL_MS || !cached.byId.has(externalId)) {
      await fetchReceiptList(c, 100);
      cached = receiptListCache.get(c.accountHash);
    }
    const receipt = cached?.byId.get(externalId);
    if (!receipt) return null;
    return sellerToMarket(receipt.head.seller);
  }
  return {
    loginWithCredentials,
    ensureFreshCredentials,
    fetchReceipts,
    fetchReceiptPdf,
    fetchReceiptItems,
    fetchReceiptSavings,
    refreshMarketInfo
  };
}
export {
  createRossmannModule as default
};
